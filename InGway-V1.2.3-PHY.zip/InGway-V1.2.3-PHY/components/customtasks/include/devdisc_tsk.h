/*
 * devdisc_tsk.h
 *
 *  Created on: Sep 29, 2020
 *      Author: liwei
 */

#ifndef COMPONENTS_CUSTOMTASKS_INCLUDE_DEVDISC_TSK_H_
#define COMPONENTS_CUSTOMTASKS_INCLUDE_DEVDISC_TSK_H_

#include <stdio.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"


#define CONFIG_BLEDEVICE_NAME			"CHINT_MCCB"
#define CONFIG_BLEDEVICE_NAMELEN		10
#define CONFIG_BLEDEVICE_MAXSURPPORT	32
#define CONFIG_BLEDEVICE_ADDR_OFFSET	100

extern QueueHandle_t mDevDiscQueueSend;
extern QueueHandle_t mDevDiscQueueRec;

extern uint8_t ucAutoDevDiscFlag;
extern void DEVDISC_Task(void *pvParameters);

#endif /* COMPONENTS_CUSTOMTASKS_INCLUDE_DEVDISC_TSK_H_ */
