/*
 * sntp_svc.h
 *
 *  Created on: Aug 8, 2020
 *      Author: liwei
 */

#ifndef EXAMPLES_WG_WG_MAIN_SNTP_SVC_H_
#define EXAMPLES_WG_WG_MAIN_SNTP_SVC_H_

#define CONFIG_DEFAULT_SNTP_TIMEOUT			10

#include <time.h>
#include <sys/time.h>

typedef void (*SntpCompleteCallBackTPDF)(struct tm *tResult);

extern void SNTP_vInit(SntpCompleteCallBackTPDF tCallback);

/*send a SNTP service data to mEthQueueRec make down device get time*/
void vSntpSendTime_CallBack(struct tm *tResult);

#endif /* EXAMPLES_WG_WG_MAIN_SNTP_SVC_H_ */
