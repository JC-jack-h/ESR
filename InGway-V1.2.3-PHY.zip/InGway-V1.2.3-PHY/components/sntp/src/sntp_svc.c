/*
 * sntp_svc.c
 *
 *  Created on: Aug 8, 2020
 *      Author: liwei
 */
#include "sntp_svc.h"
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_attr.h"
#include "esp_sntp.h"

#include "tcpSocket_tsk.h"
#include "myqueue.h"

static char *TAG = "Sntp_svc";
static TaskHandle_t mTaskHandle;
static SntpCompleteCallBackTPDF mSntpCompleteCallBack;

void vSntp_Time_Sync_Notification_Cb(struct timeval *tv)
{
}

void vSNTP_Tsk_Start(void *pvParameters)
{
	time_t tNow;
    struct tm tTimeInfo;
    uint8_t i;
    sntp_setoperatingmode(SNTP_OPMODE_POLL);
    sntp_setservername(0, "pool.ntp.org");
    sntp_set_time_sync_notification_cb(vSntp_Time_Sync_Notification_Cb);
    sntp_init();
    for(i = 0; i < CONFIG_DEFAULT_SNTP_TIMEOUT; i++)
    {
    	if(sntp_get_sync_status() != SNTP_SYNC_STATUS_RESET)
    	{
    		break;
    	}
    	vTaskDelay(100);
    }
    if(i == CONFIG_DEFAULT_SNTP_TIMEOUT)
    {
    	vTaskDelete(mTaskHandle);
    	return;
    }
    setenv("TZ", "CST-8", 1);
    tzset();
    time(&tNow);
    localtime_r(&tNow, &tTimeInfo);
    if(mSntpCompleteCallBack)
    {
    	mSntpCompleteCallBack(&tTimeInfo);
    }
    vTaskDelete(mTaskHandle);
}

void SNTP_vInit(SntpCompleteCallBackTPDF tCallback)
{
	mSntpCompleteCallBack = tCallback;
	xTaskCreate(vSNTP_Tsk_Start, "sntp task", 4096, NULL, 4, &mTaskHandle);
}

/*send a SNTP service data to mEthQueueRec make down device get time*/
void vSntpSendTime_CallBack(struct tm *tResult)
{
	MyQueueDataTPDF tMyQueueData;
	tMyQueueData.tMyQueueCommand.tMyQueueCommandType = Sntp;
	xQueueSend(mEthQueueRec, (void * )&tMyQueueData, (TickType_t)0);
	ESP_LOGI(TAG, "SNTP:year:%d,month:%d,day:%d,hour:%d,min:%d,sec:%d\n", tResult->tm_year + 1900,
																   tResult->tm_mon + 1,
																   tResult->tm_mday,
																   tResult->tm_hour,
																   tResult->tm_min,
																   tResult->tm_sec);
}