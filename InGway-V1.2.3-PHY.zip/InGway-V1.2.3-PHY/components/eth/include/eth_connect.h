/*
 * eth_connect.h
 *
 *  Created on: Oct 20, 2021
 *      Author: zchaojian
 */

#ifndef _ETH_CONNECT_H_
#define _ETH_CONNECT_H_

#include <inttypes.h>

/*Use function return Ethernet Network link status*/
extern uint8_t Eth_Connected_Status(void);
/*Inialize ehternet hardware base and register ethernet callback*/
extern void vETH_Init(void);

#endif
