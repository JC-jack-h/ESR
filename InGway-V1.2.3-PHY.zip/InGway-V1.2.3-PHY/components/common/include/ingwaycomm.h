/*
 * ingwaycomm.h
 *
 *  Created on: Jul 20, 2020
 *      Author: liwei
 */

#ifndef EXAMPLES_WG_WG_MAIN_INGWAYCOMM_H_
#define EXAMPLES_WG_WG_MAIN_INGWAYCOMM_H_

#include <stdint.h>

#define STATE_GET(source,flag)		(source & (flag)? 1:0)
#define STATE_SET(source,flag)		(source |= (flag))
#define STATE_CLEAR(source,flag)	(source &= ~(flag))

typedef enum 
{
    FUNCTION_IDLE = 0,
    FUNCTION_WORK = 1
}FunctionStateTPDF;

typedef struct 
{
    uint8_t ucCom1Enable;
    uint8_t ucCom2Enable;
    uint8_t ucCanEnable;
    uint8_t ucEthEnable;
    uint8_t ucBleEnable;
    uint8_t ucWifiEnable;
    uint8_t ucIotEnable;
    uint8_t ucDiDOEnable;
    uint8_t ucReserveEnale[8];
}SystemFucntionTPDF;

extern SystemFucntionTPDF tSystemFucntion;

typedef void (*DataRecCallBackTPDF)(char *cData, uint16_t usLen);

/*the system restart wiht software*/
void vEsp32Restart();


#endif /* EXAMPLES_WG_WG_MAIN_INGWAYCOMM_H_ */
