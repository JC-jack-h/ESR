/* Blink Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "sdkconfig.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "config_app.h"


#include "tcp_socketServer_tsk.h"
#include "tcp_socketClient_tsk.h"
#include "eth_connect.h"
#include "wifi_connect.h"

#include "devdisc_tsk.h"
#include "blink.h"
/* Can run 'make menuconfig' to choose the GPIO to blink,
   or you can edit the following line and set a number here.
*/
#define BLINK_GPIO 12

static char *TAG = "blink";


/*Network status led, GPIP  number
*/
#define GPIO_NET_MODE 	8    //SD1
#define GPIO_NET_STATUS	4

//#define GPIO_KEY 36

void vLed_Flash(eLedDisplayState tTaskState)
{
	uint8_t mTcpServerConnected = 0;
	uint8_t mTcpClientConnected = 0;

	switch(tTaskState)
	{
	case LED_ESP_TOUCH_CONFIG:
		gpio_set_level(BLINK_GPIO, 0);
		vTaskDelay(1000/ portTICK_PERIOD_MS);

		//gpio_set_level(BLINK_GPIO, 1);
		//vTaskDelay(1000 / portTICK_PERIOD_MS);
		break;
	case LED_WIFI_NOT_CONNECT:
	case LED_ETH_NOT_CONNECT:
		gpio_set_level(BLINK_GPIO, 0);
		vTaskDelay(200 / portTICK_PERIOD_MS);

		gpio_set_level(BLINK_GPIO, 1);
		vTaskDelay(200 / portTICK_PERIOD_MS);
		break;
	case GW_AUTO_DEV_DISCV_STATE:
		gpio_set_level(BLINK_GPIO, 0);
		vTaskDelay(100 / portTICK_PERIOD_MS);

		gpio_set_level(BLINK_GPIO, 1);
		vTaskDelay(100 / portTICK_PERIOD_MS);
		break;
	case GW_NORMAL_STATE:
		gpio_set_level(BLINK_GPIO, 0);
		//gpio_set_level(GPIO_NET_MODE, 0);
		// ESP_LOGW(TAG, "mWifiServerConnected: %d", mWifiServerConnected);
		// ESP_LOGW(TAG, "mWifiClientConnected: %d", mWifiClientConnected);
		mTcpServerConnected = uTcp_SocketServerConnected();
		/* Use function return tcp socket server connect status */
		mTcpClientConnected = uTcp_SocketClientConnected();
		// ESP_LOGW(TAG, "mTcpServerConnected: %d", mTcpServerConnected);
		// ESP_LOGW(TAG, "mTcpClientConnected: %d", mTcpClientConnected);
		if(mTcpServerConnected)
		{
			gpio_set_level(GPIO_NET_STATUS, 0);
		}
		else
		{
			gpio_set_level(GPIO_NET_STATUS, 1);
		}
		vTaskDelay(1000 / portTICK_PERIOD_MS);

		gpio_set_level(BLINK_GPIO, 1);
		//gpio_set_level(GPIO_NET_MODE, 1);
		//gpio_set_level(GPIO_NET_STATUS, 1);
		vTaskDelay(1000 / portTICK_PERIOD_MS);
		break;
	default:
		break;

	}
}

void sytem_blink_task()
{
    /* Configure the IOMUX register for pad BLINK_GPIO (some pads are
       muxed to GPIO on reset already, but some default to other
       functions and need to be switched to GPIO. Consult the
       Technical Reference for a list of pads and their default
       functions.)
    */
    gpio_pad_select_gpio(BLINK_GPIO);
    /* Set the GPIO as a push/pull output */
    gpio_set_direction(BLINK_GPIO, GPIO_MODE_OUTPUT);

	/*Network and other module status led*/
	/* Set the GPIO as a push/pull output */
    //gpio_pad_select_gpio(GPIO_NET_MODE);
    //gpio_set_direction(GPIO_NET_MODE, GPIO_MODE_OUTPUT);
	/* Set the GPIO as a push/pull output */
    gpio_pad_select_gpio(GPIO_NET_STATUS);
    gpio_set_direction(GPIO_NET_STATUS, GPIO_MODE_OUTPUT);

	gpio_pad_select_gpio(16);
    gpio_set_direction(16, GPIO_MODE_OUTPUT);
	gpio_set_level(16, 1);
    uint32_t uiFunction = 0;
    uiFunction = (uint32_t)mPartitionTable.usFunctionH << 16U | (uint32_t) mPartitionTable.usFunctionL;
    eLedDisplayState tTaskState;
	uint8_t ucEthConnected;
	uint8_t ucWifiConnected;

    while(1)
    {
		ucEthConnected = Eth_Connected_Status();
		ucWifiConnected = Wifi_Connected_Status();
    	tTaskState = 7;
    	if(((uiFunction & (0x3 << 10)) >> 10 == 0x01) && (mPartitionTable.tWifiConfig.usSmartConfigEnable == WIFI_SC_ENABLE))
    	{
    		tTaskState = LED_ESP_TOUCH_CONFIG;
    	}
    	else if(((uiFunction & (0x3 << 10)) >> 10 == 0x01) && (ucWifiConnected == 0))
    	{
    		tTaskState = LED_WIFI_NOT_CONNECT;
    	}
    	else if(((uiFunction & (0x3 << 6)) >> 6 == 0x01) && (ucEthConnected == 0))
    	{
    		tTaskState = LED_ETH_NOT_CONNECT;
    	}
		else if(ucAutoDevDiscFlag == 1)
		{
			tTaskState = GW_AUTO_DEV_DISCV_STATE;
		}
    	else /*if(mWifiConnected == 1)*/
    	{
    		tTaskState = GW_NORMAL_STATE;
    	}
    	//ESP_LOGW(TAG, "tTaskState:%d",tTaskState);
		//gpio_set_level(GPIO_NET_MODE, 1);
		gpio_set_level(GPIO_NET_STATUS, 1);
    	vLed_Flash(tTaskState);

    	//save inGateway connected status
    	// if (((uiFunction & (0x3 << 10)) >> 10 == 0x01) && (mWifiConnected != mPartitionTable.BasicInfor.RunState))// 0x3 << 10 take WIFI state
    	// {
    	// 	mPartitionTable.BasicInfor.RunState = mWifiConnected;
    	// 	CFG_vSaveConfig(0x020C - 1);
    	// }
    	// else if(((uiFunction & (0x3 << 6)) >> 6 == 0x01) && mConnected != mPartitionTable.BasicInfor.RunState)// 0x3 << 6 take ETH state
    	// {
    	// 	mPartitionTable.BasicInfor.RunState = mConnected;
    	// 	CFG_vSaveConfig(0x020C - 1);
    	// }
    }
}
