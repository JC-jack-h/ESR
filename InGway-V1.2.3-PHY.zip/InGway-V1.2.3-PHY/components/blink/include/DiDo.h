/*
 * DI_DO.h
 *
 *  Created on: Oct 20, 2021
 *      Author: zchaojian
 */

#ifndef COMPONENTS_DI_DO_INCLUDE_KEY_H_
#define COMPONENTS_DI_DO_INCLUDE_KEY_H_


#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "sdkconfig.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "config_app.h"

/*
 * inGw DI, DO GPIO
 */
#define GPIO_DI1 34
#define GPIO_DI2 35
#define GPIO_DO1 33
#define GPIO_DO2 32
#define DIO_LEVEL_CONNECT	1				//High connect level

typedef enum{
	DIO_LEVEL_LOW,		//Low:0
	DIO_LEVEL_HIGH	    //High:1
}enum_DIO_level;		

extern void vDiDo_task();


#endif /* COMPONENTS_DI_DO_INCLUDE_KEY_H_ */