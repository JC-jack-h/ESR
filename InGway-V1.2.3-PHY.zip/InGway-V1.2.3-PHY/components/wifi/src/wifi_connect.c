/*
 * wifi_connect.c
 *
 *  Created on: Oct 30, 2021
 *      Author: zchaojian
 */
#include "wifi_connect.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "config_app.h"
#include "wifi_svc.h"
#include "myqueue.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sntp_svc.h"
#include "tcp_socketServer_tsk.h"

static uint8_t mWifiConnected = 0;

static const char *TAG = "Wifi_Connect";

/* Set dhcp acquired IP information to mPartitionTable.tWifiConfig and save to nvs flash */
static void vWifi_Sta_Dhcp_GotIP_Save_Flash(esp_netif_ip_info_t *ip_info)
{
	uint32_t uiIndex;
	uint32_t uiSize ;
	if(mPartitionTable.tWifiConfig.usStaDHCPMode == WIFI_DHCP_MODE_DYNAMIC)
	{
		mPartitionTable.tWifiConfig.usStaIPH = ip4_addr1_16(&(ip_info->ip)) << 8U | (ip4_addr2_16(&(ip_info->ip)) & 0xFF);
		mPartitionTable.tWifiConfig.usStaIPL = ip4_addr3_16(&(ip_info->ip)) << 8U | (ip4_addr4_16(&(ip_info->ip)) & 0xFF);
		mPartitionTable.tWifiConfig.usStaGateWayH = ip4_addr1_16(&(ip_info->gw)) << 8U | (ip4_addr2_16(&(ip_info->gw)) & 0xFF);
		mPartitionTable.tWifiConfig.usStaGateWayL = ip4_addr3_16(&(ip_info->gw)) << 8U | (ip4_addr4_16(&(ip_info->gw)) & 0xFF);
		mPartitionTable.tWifiConfig.usStaSubMaskH = ip4_addr1_16(&(ip_info->netmask)) << 8U | (ip4_addr2_16(&(ip_info->netmask)) & 0xFF);
		mPartitionTable.tWifiConfig.usStaSubMaskL = ip4_addr3_16(&(ip_info->netmask)) << 8U | (ip4_addr4_16(&(ip_info->netmask)) & 0xFF);

		/* write acquired IP, GateWay, net mask address infor to nvs flash */
		uiIndex = PARTITION_TABLE_ADDR_WIFI_STAIP_HADDR - 1;//WIFI IP start address: 0x0021 - 1
		uiSize = 6;//IPH, IPL, GateWayH, GateWayL, SubMaskH, SubMaskl, write to 6 registers.
		while(uiSize)
		{
			CFG_vSaveConfig(uiIndex++);
			uiSize--;
		}
	}
}

//static void vWifi_Sntp_CallBack(struct tm *tResult)
//{
//	MyQueueDataTPDF tMyQueueData;
//	tMyQueueData.tMyQueueCommand.tMyQueueCommandType = Sntp;
//	xQueueSend(mWifiQueueRec, (void * )&tMyQueueData, (TickType_t)0);
//	ESP_LOGI(TAG, "SNTP:year:%d,month:%d,day:%d,hour:%d,min:%d,sec:%d", tResult->tm_year + 1900,
//																   tResult->tm_mon + 1,
//																   tResult->tm_mday,
//																   tResult->tm_hour,
//																   tResult->tm_min,
//																   tResult->tm_sec);
//}

/* copy wifi connected status from WIFI_vRegister_Callback() */
extern int chint_web_init(void);
extern int chint_web_stop(void);
static void vWifi_Event_CallBack(WIFIEventTPDF *tEvent)
{
	static uint8_t ucSntpDone = 0;
	switch(tEvent->tType)
	{
		case WIFI_IP_GOT:
			mWifiConnected = 1;
			vWifi_Sta_Dhcp_GotIP_Save_Flash(&(((ip_event_got_ip_t*)tEvent->tTag)->ip_info));
			if(!ucSntpDone)
			{
				SNTP_vInit(vSntpSendTime_CallBack);
				ucSntpDone = 1;
			}
			chint_web_init();
			break;
		case WIFI_STA_DISCONNECTED:
			chint_web_stop();
			mWifiConnected = 0;
			vTcp_SocketServer_Close();
			gpio_set_level(4, 1);
			gpio_set_level(16, 1);
				
			break;
		default:
			break;
	}
}

/*Inialize wi-fi hardware base and register wi-fi callback*/
void vWIFI_Init(void)
{
	WIFI_vRegister_Callback(vWifi_Event_CallBack);
	WIFI_Base_Init(&mPartitionTable.tWifiConfig);
    //WIFI_vRegister_Callback(vWifi_Event_CallBack);
}

/*Use function return wi-fi Network link status*/
uint8_t Wifi_Connected_Status(void)
{
	//ESP_LOGW(TAG, "---mWifiConnected:%d",mWifiConnected);
	return mWifiConnected;
}






