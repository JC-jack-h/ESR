/*
 * wifi_connect.h
 *
 *  Created on: Oct 30, 2021
 *      Author: zchaojian
 */

#ifndef _WIFI_CONNECT_H_
#define _WIFI_CONNECT_H_

#include <inttypes.h>

/*Use function return wi-fi Network link status*/
extern uint8_t Wifi_Connected_Status(void);
/*Inialize wi-fi hardware base and register wi-fi callback*/
extern void vWIFI_Init(void);

#endif