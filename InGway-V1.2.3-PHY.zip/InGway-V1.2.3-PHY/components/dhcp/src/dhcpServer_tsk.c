/*
 * dhcpServer_tsk.c
 *
 *  Created on: Nov 11, 2021
 *      Author: zchaojian
 */
#include "dhcpServer_tsk.h"
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_log.h"

//#include "dhcpserver.h"

/*set a dhcp server ip poll with start ip and end ip */
void vSetDhcpServerIpPoll()
{

}

void vSetDhpcServerIPAndSubmask()
{

}

void vGetDhcpInfo()
{

}


