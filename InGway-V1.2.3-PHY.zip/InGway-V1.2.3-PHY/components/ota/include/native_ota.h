/* native_ota.h
1.Create a native OTA task.

This example code is in the Public Domain (or CC0 licensed, at your option.)

Unless required by applicable law or agreed to in writing, this
software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied.
*/

#ifndef _NATIVE_OTA_H
#define _NATIVE_OTA_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#define HASH_LEN 32 /* SHA-256 digest length */

typedef enum {
	OTA_UPDATE_START = 0x01,
	OTA_UPDATE_FINISH = 0x02,
	OTA_UPDATE_TRANSACTIONID_HI = 0xFF,
	OTA_UPDATE_TRANSACTIONID_LO = 0xFF,
	OTA_UPDATE_RESERVE,
} ota_update_state_t;

/* Create a native OTA task. It can realize download BIN file through ETH or WIFI */
extern void Native_Ota_Start(void);

#ifdef __cplusplus
}
#endif

#endif
