/*
 * download_tcp_server.h
 *
 *  Created on: Mar 5, 2020
 *      Author: zchaojian
 */

#ifndef _DOWNLOAD_TCP_SERVER_H_
#define _DOWNLOAD_TCP_SERVER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include <stdint.h>



/* A function will create create a tcp server and listen the tcp client connect.
 * return server fd
 * 
 */
extern int download_tcp_server();

/* accept client link and return client fd */
extern int tcp_client_accept(int listen_sock);

/* the function will read a tcp socket transmit data.
 */
extern int tcp_server_read(int client_sock, unsigned char *buffer, int buf_len);

extern bool tcp_server_write(int client_sock, unsigned char *header_buffer, int header_buf_len, unsigned char response_state);

/* Use function return OTA tcp socket server listen status */
extern uint8_t uOTA_TcpServerListened(void);

#ifdef __cplusplus
}
#endif



#endif /* COMPONENTS_NATIVE_OTA_INCLUDE_DOWNLOAD_TCP_SERVER_H_ */
