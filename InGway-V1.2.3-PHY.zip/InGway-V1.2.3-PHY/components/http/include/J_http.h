#ifndef J_HTTP_H
#define J_HTTP_H

int chint_wifi_init_station(char* ssid, char* password);
int chint_web_init(void);
int chint_wifi_init(void);
int chint_web_stop(void);
#endif