/*
 * tcp_socketClient_tsk.h
 *
 *  Created on: Dec 10, 2020
 *      Author: zchaojian
 */

#ifndef _TCP_SOCKETCLIENT_TSK_H_
#define _TCP_SOCKETCLIENT_TSK_H_  

#include <inttypes.h>

/* Use function return tcp socket client connect status */
extern uint8_t uTcp_SocketClientConnected(void);
/* remote server down, the local client need change status */
extern void vChangeSocketClientConnectValue(uint8_t ucConnectValue);
/*tcp socket  client task initialize*/
extern void vTcpClientTask_vInit(uint32_t uiSocketIP, uint16_t usSocketPort, int iAddrFamily);
/*tcp socker client close*/
extern void vTcp_SocketClient_Close(void);

#endif /* COMPONENTS_ETH_INCLUDE_ETH_SOCKETCLIENT_TSK_H_ */
