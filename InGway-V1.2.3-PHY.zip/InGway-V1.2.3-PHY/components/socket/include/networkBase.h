 /* networkBase.h
 *
 *  Created on: Oct 20, 2021
 *      Author: zchaojian
 */

#ifndef INTERNETBASE_H
#define INTERNETBASE_H

extern void vNetworkBaseInit();

#endif