/*
 * tcpSocket_tsk.h
 *
 *  Created on: Oct 25, 2021
 *      Author: zchaojian
 */

#ifndef TCPSOCKET_TSK_H
#define TCPSOCKET_TSK_H

#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "modbus_svc.h"

//TCP max every frame size;1448=1500-20（IP header）-32（20 bytes TCP header and 12 bytes TCP option timestamp）
#define CONFIG_SOCKET_FRAME_SIZE		1448//256 
//inGway modbus address is 0x01, all device broadcast modbus address is 0x00
#define INGATEWAY_MODBUS_ADDRRESS       0x01

extern QueueHandle_t mEthQueueSend;
extern QueueHandle_t mEthQueueRec;

/*pass a structure pointer of ModbusRtuDataTPDF */
ModbusRtuDataTPDF *pModbusRtuDataRec(void);

/*tcp socket entrance*/
extern void vSocket_vTsk_Start(void *pvParameters);

#endif
