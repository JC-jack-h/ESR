 /* tcp_socketServer_tsk.h
 *
 *  Created on: Oct 20, 2021
 *      Author: zchaojian
 */

#ifndef TCP_SOCKETSERVER_TSK_H
#define TCP_SOCKETSERVER_TSK_H

#include <inttypes.h>

typedef struct 
{
    uint16_t connect_flag;
    uint16_t connect_Login;
}connect_check_t;

connect_check_t J_login_manage[100];
int connect_record[20];

/* Use function return tcp socket server listen status */
extern uint8_t uTcp_SocketServerListened(void);
/* Use function return tcp socket server connect status */
extern uint8_t uTcp_SocketServerConnected(void);
/*tcp socket server task initialize*/
extern void vTcpServerTask_vInit(void);
/*tcp socker server close*/
extern void vTcp_SocketServer_Close(void);
/*add a new tcp socket client fd to fdAllSockets*/
extern void vAddClientFdToAllSockets(int iTcplientFd);

#endif