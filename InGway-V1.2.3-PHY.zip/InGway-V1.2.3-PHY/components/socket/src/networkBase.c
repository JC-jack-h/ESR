 /* networkBase.c
 *
 *  Created on: Oct 20, 2021
 *      Author: zchaojian
 */
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_log.h"


#include "wifi_svc.h"

void vNetworkBaseInit()
{
    /*if wi-fi function start, this event group handle can create first .*/
    if(tSystemFucntion.ucWifiEnable == FUNCTION_WORK)
    {
        EventGroupHandle_t *pWifiEventGroup = NULL;
        pWifiEventGroup = eReturnWifiEventGroup();
        *pWifiEventGroup = xEventGroupCreate();
    }

    // Initialize TCP/IP network interface (should be called only once in application)
    ESP_ERROR_CHECK(esp_netif_init());
    // Create default event loop that running in background
    ESP_ERROR_CHECK(esp_event_loop_create_default());
}
