/*
 * tcpSocket_tsk.c
 *
 *  Created on: Oct 25, 2021
 *      Author: zchaojian
 */
#include "tcpSocket_tsk.h"
#include "tcp_socketServer_tsk.h"
#include "tcp_socketClient_tsk.h"
#include "myqueue.h"
#include "eth_connect.h"
#include "wifi_connect.h"

#include "config_app.h"
#include "modbus_svc.h"
#include "esp_efuse.h"

QueueHandle_t mEthQueueSend;
QueueHandle_t mEthQueueRec;

static char *TAG = "tcpSocket_tsk";
static ModbusRtuDataTPDF *mModbusRtuDataSend;
static ModbusRtuDataTPDF *mModbusRtuDataRec;
static char *mDataSend;
static char *mDataRec;
//static ModbusRtuDataTPDF *mClientModbusRtuDataSend;
//static ModbusRtuDataTPDF *mClientModbusRtuDataRec;
//static char *mClientDataSend;
//static char *mClientDataRec;

static uint8_t mConnectedLocal = 0;
static ServerProtocolTypeTPDF mServerProtocolType;

/*Public parameter initialize*/
static void vPublicParameters_Init(void)
{
	free(mModbusRtuDataSend);
	free(mModbusRtuDataRec);
	free(mDataSend);
	free(mDataRec);
	mDataSend = malloc(CONFIG_SOCKET_FRAME_SIZE);
	mDataRec = malloc(CONFIG_SOCKET_FRAME_SIZE);
	mModbusRtuDataSend = malloc(sizeof(ModbusRtuDataTPDF));
	mModbusRtuDataRec = malloc(sizeof(ModbusRtuDataTPDF));

	if(mModbusRtuDataSend && mModbusRtuDataRec)
	{
		mModbusRtuDataSend->tModbusMstSlvMode = MODBUS_MODE_SLAVE;
		mModbusRtuDataRec->tModbusMstSlvMode = MODBUS_MODE_SLAVE;
		mModbusRtuDataSend->ucEffect = MODBUS_RESULT_FAIL;
		mModbusRtuDataRec->ucEffect = MODBUS_RESULT_FAIL;
		mModbusRtuDataSend->ucError = 0;
		mModbusRtuDataRec->ucError = 0;
	}

	//free(mClientModbusRtuDataSend);
	//free(mClientModbusRtuDataRec);
	//free(mClientDataSend);
	//free(mClientDataRec);
	//mClientDataSend = malloc(CONFIG_SOCKET_FRAME_SIZE);
	//mClientDataRec = malloc(CONFIG_SOCKET_FRAME_SIZE);
	//mClientModbusRtuDataSend = malloc(sizeof(ModbusRtuDataTPDF));
	//mClientModbusRtuDataRec = malloc(sizeof(ModbusRtuDataTPDF));
	//mClientModbusRtuDataSend->tModbusMstSlvMode = MODBUS_MODE_SLAVE;
	//mClientModbusRtuDataRec->tModbusMstSlvMode = MODBUS_MODE_SLAVE;
	//mClientModbusRtuDataSend->ucEffect = MODBUS_RESULT_FAIL;
	//mClientModbusRtuDataRec->ucEffect = MODBUS_RESULT_FAIL;
	//mClientModbusRtuDataSend->ucError = 0;
	//mClientModbusRtuDataRec->ucError = 0;
}

static void vTcpSockets_vInit(void)
{
	mServerProtocolType = (ServerProtocolTypeTPDF)0;
	uint32_t uiModbusIP = 0;
	uint16_t usModbusPort = 0;
	if(mPartitionTable.tServer1Config.usCommType == SERVER_COMM_TYPE_ETH \
		|| mPartitionTable.tServer1Config.usCommType == SERVER_COMM_TYPE_WIFI \
		|| mPartitionTable.tServer1Config.usCommType == SERVER_COMM_TYPE_AUTO )
	{
		uiModbusIP = CFG_dConvertString_To_IP((char *)mPartitionTable.tServer1Config.cIP);
		usModbusPort = mPartitionTable.tServer1Config.usPort;
		mServerProtocolType = (ServerProtocolTypeTPDF)mPartitionTable.tServer1Config.usProtocolType;
	}
	// else if(mPartitionTable.tServer2Config.usCommType == SERVER_COMM_TYPE_ETH 
	// 	|| mPartitionTable.tServer2Config.usCommType == SERVER_COMM_TYPE_WIFI 
	//	|| mPartitionTable.tServer2Config.usCommType == SERVER_COMM_TYPE_AUTO )
	// {
	// 	uiModbusIP = CFG_dConvertString_To_IP((char *)mPartitionTable.tServer2Config.cIP);
	// 	usModbusPort = mPartitionTable.tServer2Config.usPort;
	// 	mServerProtocolType = (ServerProtocolTypeTPDF)mPartitionTable.tServer2Config.usProtocolType;
	// }
	ESP_LOGW(TAG, "Remote tcp server Init:IP = %x,Port = %d",uiModbusIP,usModbusPort);
	vPublicParameters_Init();
	vTcpServerTask_vInit(); 
	ESP_LOGI(TAG, "mServerProtocolType:%d", mServerProtocolType);
	switch(mServerProtocolType)
	{
		case SERVER_PROTOCOL_TYPE_MQTT:
			break;
		case SERVER_PROTOCOL_TYPE_MODBUS_RTU:
			vTcpClientTask_vInit(uiModbusIP, usModbusPort, AF_INET);//tcp   client  task
			break;
		default:
			break;
	}

}

static esp_efuse_coding_scheme_t get_coding_scheme(void)
{
    // The coding scheme is used for EFUSE_BLK1, EFUSE_BLK2 and EFUSE_BLK3.
    // We use EFUSE_BLK3 (custom block) to verify it.
    esp_efuse_coding_scheme_t coding_scheme = esp_efuse_get_coding_scheme(EFUSE_BLK3);
    if (coding_scheme == EFUSE_CODING_SCHEME_NONE) {
        ESP_LOGI(TAG, "Coding Scheme NONE");
#if CONFIG_IDF_TARGET_ESP32
    } else if (coding_scheme == EFUSE_CODING_SCHEME_3_4) {
        ESP_LOGI(TAG, "Coding Scheme 3/4");
    } else {
        ESP_LOGI(TAG, "Coding Scheme REPEAT");
    }
#else
    } else if (coding_scheme == EFUSE_CODING_SCHEME_RS) {
        ESP_LOGI(TAG, "Coding Scheme RS (Reed-Solomon coding)");
    }
#endif
    return coding_scheme;
}


	//HW store in efuse 
	const esp_efuse_desc_t HW_VERSION_1[] = {
		{EFUSE_BLK1, 0, 8}, 	 // Module version,
	};
	const esp_efuse_desc_t HW_VERSION_2[] = {
		{EFUSE_BLK1, 8, 8}, 	 // Module version,
	};
	const esp_efuse_desc_t HW_VERSION_3[] = {
		{EFUSE_BLK1, 16, 8}, 	 // Module version,
	};

	//SN store in efuse
	const esp_efuse_desc_t SN_EFUSE[] = {
		{EFUSE_BLK2, 0, 8 * 24}, 	 // Module version,
	};

	const esp_efuse_desc_t* SN_ZONE[] = {
		&SN_EFUSE[0],    		// Module version
		NULL
	};

	const esp_efuse_desc_t* ESP_EFUSE_HW_VERSION_1[] = {
		&HW_VERSION_1[0],    		// Module version
		NULL
	};

	const esp_efuse_desc_t* ESP_EFUSE_HW_VERSION_2[] = {
		&HW_VERSION_2[0],    		// Module version
		NULL
	};

	const esp_efuse_desc_t* ESP_EFUSE_HW_VERSION_3[] = {
		&HW_VERSION_3[0],    		// Module version
		NULL
	};


int J_hw_store(uint8_t *hw)
{
	uint8_t a = 0,b = 0,c = 0;	
    ESP_ERROR_CHECK(esp_efuse_read_field_blob(ESP_EFUSE_HW_VERSION_1, &a, 8));
    ESP_ERROR_CHECK(esp_efuse_read_field_blob(ESP_EFUSE_HW_VERSION_2, &b, 8));	
	ESP_ERROR_CHECK(esp_efuse_read_field_blob(ESP_EFUSE_HW_VERSION_3, &c, 8));	
	int h = hw[0]<<16 | hw[1]<<8 | hw[2];
    ESP_LOGE("efuse","a = %x,b = %x,c = %x,check h = %x",a,b,c,h);
	
    if(a == 0 && b == 0 && h != 0)
    {
        esp_efuse_coding_scheme_t coding_scheme = get_coding_scheme();
        // ESP_LOGI(TAG, "write custom efuse fields :%d",esp_efuse_get_field_size(ESP_EFUSE_HW_VERSION_H));
        if (coding_scheme == EFUSE_CODING_SCHEME_REPEAT) {
            ESP_LOGI(TAG, "In the case of 3/4 or RS coding scheme, you cannot write efuse fields separately");
            ESP_LOGI(TAG, "You should use the batch mode of writing fields for this");
            ESP_ERROR_CHECK(esp_efuse_batch_write_begin());
        }
        uint8_t HW_H = hw[0];
        uint8_t HW_M = hw[1];
		uint8_t HW_L = hw[2];
        ESP_ERROR_CHECK(esp_efuse_write_field_blob(ESP_EFUSE_HW_VERSION_1, &HW_H, 8));
		ESP_ERROR_CHECK(esp_efuse_write_field_blob(ESP_EFUSE_HW_VERSION_2, &HW_M, 8));
        ESP_ERROR_CHECK(esp_efuse_write_field_blob(ESP_EFUSE_HW_VERSION_3, &HW_L, 8));
        ESP_LOGE("TAG","---------------");

        if (coding_scheme == EFUSE_CODING_SCHEME_REPEAT) {
            ESP_ERROR_CHECK(esp_efuse_batch_write_commit());
        }
		return 0x0A;
    }

    return 0x0B;
}


int J_sn_store(uint8_t *src)
{
	char sn_test[25];
	char sn[24];
	ESP_ERROR_CHECK(esp_efuse_read_field_blob(SN_ZONE, sn_test, 8*24));
	sn_test[24] = '\0';
	ESP_LOGI(TAG, "sn_test read :%s",sn_test);

	memcpy(sn,src,24);
	if(sn_test[0] == 0 &&  sn[0] >= '0' && sn[19] >= '0')
    {
		ESP_LOGE(TAG, "efuse write sn :%s",sn);
        esp_efuse_coding_scheme_t coding_scheme = get_coding_scheme();
        // ESP_LOGI(TAG, "write custom efuse fields :%d",esp_efuse_get_field_size(ESP_EFUSE_HW_VERSION_H));
        if (coding_scheme == EFUSE_CODING_SCHEME_REPEAT) {
            ESP_LOGI(TAG, "In the case of 3/4 or RS coding scheme, you cannot write efuse fields separately");
            ESP_LOGI(TAG, "You should use the batch mode of writing fields for this");
            ESP_ERROR_CHECK(esp_efuse_batch_write_begin());
        }
        ESP_LOGE("TAG","---------------");
        
        ESP_ERROR_CHECK(esp_efuse_write_field_blob(SN_ZONE, sn, 8*24));

        if (coding_scheme == EFUSE_CODING_SCHEME_REPEAT) {
            ESP_ERROR_CHECK(esp_efuse_batch_write_commit());
        }
		return 0x0A;
    }

	if(sn[0] == 0)
	{
		return 0x0C;
	}

    return 0x0B;
}

uint16_t Zhong_Xin_Login = 0;
uint16_t Zhong_xin_Switch = 0;
uint16_t Zhong_Xin_Unlock = 0;
uint8_t ef_hw[3] = {0};
int log = 5;
int hw_res = 0;
int sn_res = 0;
extern uint8_t mTcpServerConnected;
static void Eth_Socket_vTsk(uint8_t ucConnected, MyQueueDataTPDF tMyQueueData)
{
	uint16_t i;
	mConnectedLocal = ucConnected;
	// //get Switch state
	// char MP_Switch[16] = {0};
	// uint16_t Len = sizeof(mPartitionTable.ZhongXin.zxSwitch) / 2;
	// char *s = mPartitionTable.ZhongXin.zxSwitch;
	// // "F" "N"
	
	// for(uint16_t i = 0;i < 1;i++)
	// {	
	// 	MP_Switch[i] = *(s++);
	// }

	// if(log)
	// {
	// 	log = 0;
	// 	ESP_LOGW("133","MP_Switch = %s",MP_Switch);
	// }
		

	// if(MP_Switch[0] == 'N')
	// {
	// 	Zhong_xin_Switch = 6;
	// }
	// else if(MP_Switch[0] == 'F')
	// {
	// 	Zhong_xin_Switch = 9;
	// }
	
	// Zhong_Xin_Login |= Zhong_xin_Switch<<4;
	// uint8_t *c = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_CHECK - 1) * 2);
	// *(c+1)= Zhong_Xin_Login;
	
	
	if(xQueueReceive(mEthQueueSend, (void * )&tMyQueueData, (portTickType)0))
	{
		mModbusRtuDataSend->tFunction = tMyQueueData.tMyQueueCommand.tMyQueueCommandType;
		mModbusRtuDataSend->ucSlaveAddr = tMyQueueData.tMyQueueCommand.usSlaveAddr;
		mModbusRtuDataSend->usRegAddr = tMyQueueData.tMyQueueCommand.usRegAddr;
		mModbusRtuDataSend->usRegCount = tMyQueueData.tMyQueueCommand.usRegLen;
		mModbusRtuDataSend->usDataLen = tMyQueueData.tMyQueueCommand.usDatalen;
		mModbusRtuDataSend->ucError = tMyQueueData.tMyQueueCommand.ucError;
		ESP_LOGI(TAG, "DataLen: %d, Error: %d", tMyQueueData.tMyQueueCommand.usDatalen, tMyQueueData.tMyQueueCommand.ucError);
		memcpy(mModbusRtuDataSend->ucData,tMyQueueData.tMyQueueCommand.cData, tMyQueueData.tMyQueueCommand.usDatalen);
		mModbusRtuDataSend->usHead = tMyQueueData.Reserver[1];
		i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
		ESP_LOGI(TAG, "i: %d, %s, %d", i, __func__,__LINE__);
		ETH_vData_Send(tMyQueueData.Reserver[0], mDataSend, i);
		i = 0;
	}
	if(mModbusRtuDataRec->ucEffect == MODBUS_RESULT_SUCCESS)//MODBUS_RESULT_SUCCESS means MB RTU data frame analysis success
	{
		//inGway modbus address is 0x01, all device broadcast modbus address is 0x00
		//if(mModbusRtuDataRec->ucSlaveAddr == INGATEWAY_MODBUS_ADDRRESS)
		if(mModbusRtuDataRec->ucSlaveAddr == mPartitionTable.GatewayInfor.ModbusAddr)
		{
			if(mModbusRtuDataRec->usRegAddr == 0x01fd && mModbusRtuDataRec->tFunction == WriteReg)
			{
				mModbusRtuDataRec->ucEffect = MODBUS_RESULT_FAIL;
				switch(mModbusRtuDataRec->ucData[1])
				{
					case 1:
						tMyQueueData.tMyQueueCommand.tMyQueueCommandType = DeviceDiscoveryReStart;
						break;
					case 2:
						tMyQueueData.tMyQueueCommand.tMyQueueCommandType = DeviceDiscoveryContinue;
						break;
					default:
						tMyQueueData.tMyQueueCommand.tMyQueueCommandType = DeviceDiscoveryStop;
						break;
				}
				xQueueSend(mEthQueueRec, (void * )&tMyQueueData, (TickType_t)0);
				mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead;
				mModbusRtuDataSend->ucSlaveAddr = 0;
				mModbusRtuDataSend->tFunction = WriteReg;
				mModbusRtuDataSend->usRegAddr = 0x01fd;
				mModbusRtuDataSend->ucData[0] = mModbusRtuDataRec->ucData[0];
				mModbusRtuDataSend->ucData[1] = mModbusRtuDataRec->ucData[1];
				mModbusRtuDataSend->ucError = 0;
				i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
				ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
			}
			else if (mModbusRtuDataRec->usRegAddr == 0x01fd && mModbusRtuDataRec->tFunction == WriteMultReg)
			{
				mModbusRtuDataRec->ucEffect = MODBUS_RESULT_FAIL;
				switch(mModbusRtuDataRec->ucData[1])
				{
					case 1:
						tMyQueueData.tMyQueueCommand.tMyQueueCommandType = DeviceDiscoveryReStart;
						break;
					case 2:
						tMyQueueData.tMyQueueCommand.tMyQueueCommandType = DeviceDiscoveryContinue;
						break;
					default:
						tMyQueueData.tMyQueueCommand.tMyQueueCommandType = DeviceDiscoveryStop;
						break;
				}
				xQueueSend(mEthQueueRec, (void * )&tMyQueueData, (TickType_t)0);
				mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead;
				mModbusRtuDataSend->ucSlaveAddr = 0;
				mModbusRtuDataSend->tFunction = WriteMultReg;
				mModbusRtuDataSend->usRegAddr = mModbusRtuDataRec->usRegAddr;
				mModbusRtuDataSend->usDataLen = mModbusRtuDataRec->usDataLen;
				mModbusRtuDataSend->usRegCount = mModbusRtuDataRec->usRegCount;
				mModbusRtuDataSend->ucData[0] = mModbusRtuDataRec->ucData[0];
				mModbusRtuDataSend->ucData[1] = mModbusRtuDataRec->ucData[1];
				mModbusRtuDataSend->ucError = 0;
				i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
				esp_log_buffer_hex(TAG, mDataSend, i);
				ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
			}
			#if 0
			else if (mModbusRtuDataRec->usRegAddr == 0x2000 && mModbusRtuDataRec->tFunction == WriteMultReg)
			{
				//Root PWD check
				ESP_LOGE("LOGIN","0x2000 Reg Write,data = %x,%x,%x,%x,%x,%x,%x,%x",mModbusRtuDataRec->ucData[0],mModbusRtuDataRec->ucData[1],mModbusRtuDataRec->ucData[2],mModbusRtuDataRec->ucData[3],mModbusRtuDataRec->ucData[4],mModbusRtuDataRec->ucData[5],mModbusRtuDataRec->ucData[6],mModbusRtuDataRec->ucData[7]);
				// J_ZX_info_store(&mModbusRtuDataRec, &tModbusRtuDataSend);
				char MP_Unlock[16] = {0};
				char Rec_Unlock[16] = {0};
				uint16_t usDataLen = mModbusRtuDataRec->usRegCount * 2;

				uint8_t *j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_UNLOCK - 1) * 2);
				ESP_LOGE("tag","MP_Unlock j = %d,%s",(int)j,(char *)j);
				for(uint8_t i = 0; i < usDataLen; i++)
				{
					MP_Unlock[i * 2 + 1] = *(j++);
					MP_Unlock[i * 2] = *(j++);
				}
				ESP_LOGE("MP_Unlock", "%s",MP_Unlock);
				j = mModbusRtuDataRec->ucData;
				for(uint8_t i = 0; i < usDataLen; i++)
				{
					Rec_Unlock[i] = *(j++);
				}
				ESP_LOGE("Rec_Unlock", "%s",Rec_Unlock);
				if(strcmp((const char *)MP_Unlock,(const char *)Rec_Unlock) == 0)
				{
					ESP_LOGW("heheda","check Unlock OK");
					Zhong_Xin_Unlock |= 0xFF;
				}
				
				mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead; //基本回复
				mModbusRtuDataSend->ucSlaveAddr = 0;
				mModbusRtuDataSend->tFunction = WriteMultReg;
				mModbusRtuDataSend->usRegAddr = mModbusRtuDataRec->usRegAddr;
				mModbusRtuDataSend->usDataLen = mModbusRtuDataRec->usDataLen;
				mModbusRtuDataSend->usRegCount = mModbusRtuDataRec->usRegCount;
				mModbusRtuDataSend->ucError = 0;
				i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
				esp_log_buffer_hex(TAG, mDataSend, i);
				ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
			}
			else if (mModbusRtuDataRec->usRegAddr == 0x2008 && mModbusRtuDataRec->tFunction == WriteMultReg)
			{
			// Account check
				ESP_LOGE("LOGIN","0x2008 Reg Write,data = %x,%x,%x,%x,%x,%x,%x,%x",mModbusRtuDataRec->ucData[0],mModbusRtuDataRec->ucData[1],mModbusRtuDataRec->ucData[2],mModbusRtuDataRec->ucData[3],mModbusRtuDataRec->ucData[4],mModbusRtuDataRec->ucData[5],mModbusRtuDataRec->ucData[6],mModbusRtuDataRec->ucData[7]);
				// J_ZX_info_store(&mModbusRtuDataRec, &tModbusRtuDataSend);
				char MP_Account[48] = {0};
				char Rec_Account[48] = {0};
				uint16_t usDataLen = mModbusRtuDataRec->usRegCount * 2;
				uint8_t *j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_ACCOUNT - 1) * 2);
				ESP_LOGE("tag","Pwd j = %d,%s",(int)j,(char *)j);
				for(uint8_t i = 0; i < ZHONGXIN_REG_COUNT; i++)
				{
					MP_Account[i * 2 + 1] = *(j++);
					MP_Account[i * 2] = *(j++);
				}
				ESP_LOGE("MP_Account", "%s",MP_Account);
				j = mModbusRtuDataRec->ucData;
				for(uint8_t i = 0; i < usDataLen; i++)
				{
					Rec_Account[i] = *(j++);
				}
				ESP_LOGE("Rec_Account", "%s , mModbusRtuDataRec->tTag = %d",Rec_Account,(int)mModbusRtuDataRec->tTag);
				if(strcmp((const char *)MP_Account,(const char *)Rec_Account) == 0)
				{
					// Zhong_Xin_Login &= 0xF0;
					// Zhong_Xin_Login |= 3;
					
					J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login &= 0xF0;
					J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login |= 3;
					
					
					ESP_LOGW("heheda","check Account OK J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login = %x",J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login);
				}
				else
				{
					// Zhong_Xin_Login &= 0xF0; 
					J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login &= 0xF0;
					ESP_LOGW("heheda","check Account filed J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login = %x",J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login);
				}

				j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_CHECK - 1) * 2); //更新登录状态
				*(j+1)= Zhong_Xin_Login;

				mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead; //基本回复
				mModbusRtuDataSend->ucSlaveAddr = 0;
				mModbusRtuDataSend->tFunction = WriteMultReg;
				mModbusRtuDataSend->usRegAddr = mModbusRtuDataRec->usRegAddr;
				mModbusRtuDataSend->usDataLen = mModbusRtuDataRec->usDataLen;
				mModbusRtuDataSend->usRegCount = mModbusRtuDataRec->usRegCount;
				mModbusRtuDataSend->ucError = 0;
				ESP_LOGE("d","mModbusRtuDataSend->tModbusMstSlvMode = %d",mModbusRtuDataSend->tModbusMstSlvMode);
				i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
				esp_log_buffer_hex(TAG, mDataSend, i);
				ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
			}
			else if (mModbusRtuDataRec->usRegAddr == 0x2010 && mModbusRtuDataRec->tFunction == WriteMultReg)
			{
				// password check
				ESP_LOGE("LOGIN","0x2010 Reg Write,data = %x,%x,%x,%x,%x,%x,%x,%x",mModbusRtuDataRec->ucData[0],mModbusRtuDataRec->ucData[1],mModbusRtuDataRec->ucData[2],mModbusRtuDataRec->ucData[3],mModbusRtuDataRec->ucData[4],mModbusRtuDataRec->ucData[5],mModbusRtuDataRec->ucData[6],mModbusRtuDataRec->ucData[7]);
				// J_ZX_info_store(&mModbusRtuDataRec, &tModbusRtuDataSend);
				char MP_Pwd[48] = {0};
				char Rec_Pwd[48] = {0};
				uint16_t usDataLen = mModbusRtuDataRec->usRegCount * 2;
				uint8_t *j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_PWD - 1) * 2);
				ESP_LOGE("tag","Pwd j = %d,%s",(int)j,(char *)j);
				for(uint8_t i = 0; i < ZHONGXIN_REG_COUNT; i++)
				{
					MP_Pwd[i * 2 + 1] = *(j++);
					MP_Pwd[i * 2] = *(j++);
				}
				ESP_LOGE("MP_Pwd", "%s",MP_Pwd);
				j = mModbusRtuDataRec->ucData;
				for(uint8_t i = 0; i < usDataLen; i++)
				{
					Rec_Pwd[i] = *(j++);
				}
				ESP_LOGE("Rec-Pwd", "%s",Rec_Pwd);
				
					if(strcmp((const char *)MP_Pwd,(const char *)Rec_Pwd) == 0 && J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login == 0x63)
				{
					// Zhong_Xin_Login |= 3<<2;
					J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login |= 3<<2;
					ESP_LOGW("heheda","check Password OK J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login = %x",J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login);
				}
				else
				{
					// Zhong_Xin_Login &= 0xF0; 
					J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login &= 0xF0;
					ESP_LOGW("heheda","check Password filed J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login = %x",J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login);
				}

				j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_CHECK - 1) * 2);
				*(j+1)= Zhong_Xin_Login;

				mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead;   //基本回复
				mModbusRtuDataSend->ucSlaveAddr = 0;
				mModbusRtuDataSend->tFunction = WriteMultReg;
				mModbusRtuDataSend->usRegAddr = mModbusRtuDataRec->usRegAddr;
				mModbusRtuDataSend->usDataLen = mModbusRtuDataRec->usDataLen;
				mModbusRtuDataSend->usRegCount = mModbusRtuDataRec->usRegCount;
				mModbusRtuDataSend->ucError = 0;
				i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
				esp_log_buffer_hex(TAG, mDataSend, i);
				ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
			}
			else if (mModbusRtuDataRec->usRegAddr == 0x2018 && mModbusRtuDataRec->tFunction == WriteMultReg) //密码模式 开关控制
			{
				//Switch
				uint16_t usDataLen = mModbusRtuDataRec->usRegCount * 2;

				char Rec_Switch[16] = {0};
				uint8_t *j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_SWITCH - 1) * 2);
				for(uint8_t i = 0; i < 1; i++)
				{
					MP_Switch[i] = *(j++);
				}
				ESP_LOGW("327","MP_Switch = %s",MP_Switch);
				j = mModbusRtuDataRec->ucData;

				for(uint8_t i = 0; i < 1; i++)
				{
					Rec_Switch[i] = *(j++);
				}
				ESP_LOGW("334","Rec_Switch = %s",Rec_Switch);
				if(Rec_Switch[0] == 'N' || Rec_Switch[0] == 'F')
				{
					if(Rec_Switch[0] != MP_Switch[0])
					{
						j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_SWITCH - 1) * 2);
						for(uint8_t i = 0;i < 8;i++)
						{
							*j++ = 0;                          //有脏东西，手动清空 Switch
							*j++ = 0;
						}

						char * s = Rec_Switch;
						j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_SWITCH - 1) * 2);
						for(uint8_t i = 0; i < 1; i++)
						{
							j[i] = *s++;
						}

						j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_SWITCH - 1) * 2);
						for(uint8_t i = 0; i < 1; i++)
						{
							MP_Switch[i] = *j++;   //更新switch变量
						}
						ESP_LOGE(" ","change MP_SWITCH = %s",MP_Switch);

						CFG_vSaveConfig((ZHONGXIN_SWITCH - 1));        // 存储switch状态
						if(MP_Switch[0] == 'N')
						{
							Zhong_xin_Switch = 6;
						}
						else if(MP_Switch[0] == 'F')
						{
							Zhong_xin_Switch = 9;
						}
						Zhong_Xin_Login = 0;
						Zhong_Xin_Login |= Zhong_xin_Switch<<4;       //Login 绑定switch状态

						for(uint8_t i = 0;i < 20;i++)
						{
							if(connect_record[i] != 0)
							{
								J_login_manage[connect_record[i]].connect_Login = 0;
								J_login_manage[connect_record[i]].connect_Login |= Zhong_xin_Switch<<4;   //开关切换时所有连接相应状态修改
								ESP_LOGW("heheda","J_login_manage[connect_record[%d]].connect_Login = %x",i,J_login_manage[connect_record[i]].connect_Login);
							}
						}
						ESP_LOGW("heheda","Zhong_xin_Switch = %x,Zhong_Xin_Login = %x",Zhong_xin_Switch,Zhong_Xin_Login);
						
						j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_CHECK - 1) * 2);
						*(j+1)= Zhong_Xin_Login;
						
						mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead; //基本回复
						mModbusRtuDataSend->ucSlaveAddr = 0;
						mModbusRtuDataSend->tFunction = WriteMultReg;
						mModbusRtuDataSend->usRegAddr = mModbusRtuDataRec->usRegAddr;
						mModbusRtuDataSend->usDataLen = mModbusRtuDataRec->usDataLen;
						mModbusRtuDataSend->usRegCount = mModbusRtuDataRec->usRegCount;
						mModbusRtuDataSend->ucData[0] = mModbusRtuDataRec->ucData[0];
						mModbusRtuDataSend->ucData[1] = mModbusRtuDataRec->ucData[1];
						mModbusRtuDataSend->ucError = 0;
						i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
						esp_log_buffer_hex(TAG, mDataSend, i);
						ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
					}
				}
			}
			else if (mModbusRtuDataRec->usRegAddr == 0x2020 && mModbusRtuDataRec->tFunction == ReadReg)
			{
				// password check
				ESP_LOGE("CHECK","0x2020 Reg,data = %x,%x,%x,%x,%x,%x,%x,%x",mModbusRtuDataRec->ucData[0],mModbusRtuDataRec->ucData[1],mModbusRtuDataRec->ucData[2],mModbusRtuDataRec->ucData[3],mModbusRtuDataRec->ucData[4],mModbusRtuDataRec->ucData[5],mModbusRtuDataRec->ucData[6],mModbusRtuDataRec->ucData[7]);
				// J_ZX_info_store(&mModbusRtuDataRec, &tModbusRtuDataSend);
				uint8_t *j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_CHECK - 1) * 2);

				mModbusRtuDataSend->ucEffect = MODBUS_RESULT_SUCCESS;
				mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead;   //基本回复
				mModbusRtuDataSend->ucSlaveAddr = 0;
				mModbusRtuDataSend->tFunction = ReadReg;
				mModbusRtuDataSend->usRegAddr = mModbusRtuDataRec->usRegAddr;
				mModbusRtuDataSend->usDataLen = mModbusRtuDataRec->usRegCount * 2;
				mModbusRtuDataSend->usRegCount = mModbusRtuDataRec->usRegCount;

				// for(uint8_t i = 0; i < mModbusRtuDataRec->usRegCount; i++)
				// {
				// 	mModbusRtuDataSend->ucData[i * 2 + 1] = *(j++);
				// 	mModbusRtuDataSend->ucData[i * 2] = *(j++);
				// }
				mModbusRtuDataSend->ucData[0] = J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login & 0xFF;
				mModbusRtuDataSend->ucData[1] = Zhong_Xin_Login & 0xF;

				mModbusRtuDataSend->ucError = 0;
				ESP_LOGE("d","mModbusRtuDataSend->tModbusMstSlvMode = %d",mModbusRtuDataSend->tModbusMstSlvMode);
				i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
				esp_log_buffer_hex(TAG, mDataSend, i);
				ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
			}
			else if (mModbusRtuDataRec->usRegAddr == 0x2028 && mModbusRtuDataRec->tFunction == ReadReg) //返回TCP连接数量，(0,3)
			{
				// password check
				ESP_LOGE("CHECK","0x2028 Reg,data = %x,%x,%x,%x,%x,%x,%x,%x",mModbusRtuDataRec->ucData[0],mModbusRtuDataRec->ucData[1],mModbusRtuDataRec->ucData[2],mModbusRtuDataRec->ucData[3],mModbusRtuDataRec->ucData[4],mModbusRtuDataRec->ucData[5],mModbusRtuDataRec->ucData[6],mModbusRtuDataRec->ucData[7]);
				// J_ZX_info_store(&mModbusRtuDataRec, &tModbusRtuDataSend);
				uint8_t *j = ((uint8_t *)&mPartitionTable) + ((ZHONGXIN_CHECK - 1) * 2);

				mModbusRtuDataSend->ucEffect = MODBUS_RESULT_SUCCESS;
				mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead;   //基本回复
				mModbusRtuDataSend->ucSlaveAddr = 0;
				mModbusRtuDataSend->tFunction = ReadReg;
				mModbusRtuDataSend->usRegAddr = mModbusRtuDataRec->usRegAddr;
				mModbusRtuDataSend->usDataLen = mModbusRtuDataRec->usRegCount * 2;
				mModbusRtuDataSend->usRegCount = mModbusRtuDataRec->usRegCount;

				// for(uint8_t i = 0; i < mModbusRtuDataRec->usRegCount; i++)
				// {
				// 	mModbusRtuDataSend->ucData[i * 2 + 1] = *(j++);
				// 	mModbusRtuDataSend->ucData[i * 2] = *(j++);
				// }
				mModbusRtuDataSend->ucData[0] = 0xCC;
				mModbusRtuDataSend->ucData[1] = mTcpServerConnected;

				mModbusRtuDataSend->ucError = 0;
				i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
				esp_log_buffer_hex(TAG, mDataSend, i);
				ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
			}
			#endif
			else if (mModbusRtuDataRec->usRegAddr == 0x2030) //efuse写入3段HW版本号
			{
				// password check
				if(mModbusRtuDataRec->tFunction == WriteMultReg)
				{
					ESP_LOGE("CHECK","0x2030 WriteMultReg,data = %x,%x,%x,%x,%x,%x,%x,%x",mModbusRtuDataRec->ucData[0],mModbusRtuDataRec->ucData[1],mModbusRtuDataRec->ucData[2],mModbusRtuDataRec->ucData[3],mModbusRtuDataRec->ucData[4],mModbusRtuDataRec->ucData[5],mModbusRtuDataRec->ucData[6],mModbusRtuDataRec->ucData[7]);
					int hw_check = 0;
					hw_check = mModbusRtuDataRec->ucData[0]<<8 | mModbusRtuDataRec->ucData[1];
					if(hw_check >= 0x0100)
					{
						ef_hw[0] = mModbusRtuDataRec->ucData[0];
						ef_hw[1] = mModbusRtuDataRec->ucData[1];
						ef_hw[2] = mModbusRtuDataRec->ucData[2];
						int e = (ef_hw[0] << 8) | ef_hw[1];
						e = e + ef_hw[2];                        //判断版本号大于 1.0.0 有效
						if(e > 0x0100)
						{
							hw_res = J_hw_store(ef_hw);
							ESP_LOGE("W","hw_res = %x",hw_res);
							if(hw_res == 0x0A)
							{
								mPartitionTable.BasicInfor.HardwareVersion = (ef_hw[0] << 8) | ef_hw[1];
							}
						}
						else
						{
							hw_res = 0x0C;
						}
					}
					else
					{
						hw_res = 0x0C;
					}
					
					mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead;   //基本回复
					mModbusRtuDataSend->ucSlaveAddr = 0;
					mModbusRtuDataSend->tFunction = WriteMultReg;
					mModbusRtuDataSend->usRegAddr = mModbusRtuDataRec->usRegAddr;
					mModbusRtuDataSend->usDataLen = mModbusRtuDataRec->usDataLen;
					mModbusRtuDataSend->usRegCount = mModbusRtuDataRec->usRegCount;
					mModbusRtuDataSend->ucError = 0;
				}

				if(mModbusRtuDataRec->tFunction == ReadReg)
				{
					uint8_t e = 0,f = 0,g = 0;	
					ESP_ERROR_CHECK(esp_efuse_read_field_blob(ESP_EFUSE_HW_VERSION_1, &e, 8));
					ESP_ERROR_CHECK(esp_efuse_read_field_blob(ESP_EFUSE_HW_VERSION_2, &f, 8));	
					ESP_ERROR_CHECK(esp_efuse_read_field_blob(ESP_EFUSE_HW_VERSION_3, &g, 8));	

					mModbusRtuDataSend->ucEffect = MODBUS_RESULT_SUCCESS;
					mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead;   //基本回复
					mModbusRtuDataSend->ucSlaveAddr = 0;
					mModbusRtuDataSend->tFunction = ReadReg;
					mModbusRtuDataSend->usRegAddr = mModbusRtuDataRec->usRegAddr;
					mModbusRtuDataSend->usDataLen = mModbusRtuDataRec->usRegCount * 2;
					mModbusRtuDataSend->usRegCount = mModbusRtuDataRec->usRegCount;
					mModbusRtuDataSend->ucData[0] = 0xEF;
					ESP_LOGE("R","hw_res = %x",hw_res);
					mModbusRtuDataSend->ucData[1] = hw_res;

					if(mModbusRtuDataRec->usRegCount == 3)
					{
						mModbusRtuDataSend->ucData[2] = 0;
						mModbusRtuDataSend->ucData[3] = e;
						mModbusRtuDataSend->ucData[4] = f;
						mModbusRtuDataSend->ucData[5] = g;
					}
					mModbusRtuDataSend->ucError = 0;
				}
				
				ESP_LOGE("d","mModbusRtuDataSend->tModbusMstSlvMode = %d",mModbusRtuDataSend->tModbusMstSlvMode);
				i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
				ESP_LOGE("CHECK","mModbusRtuDataSend data = %x,%x,%x,%x,%x,%x,%x,%x",mModbusRtuDataSend->ucData[0],mModbusRtuDataSend->ucData[1],mModbusRtuDataSend->ucData[2],mModbusRtuDataSend->ucData[3],mModbusRtuDataSend->ucData[4],mModbusRtuDataSend->ucData[5],mModbusRtuDataSend->ucData[6],mModbusRtuDataSend->ucData[7]);
				esp_log_buffer_hex(TAG, mDataSend, i);
				ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
				mModbusRtuDataRec->usRegAddr = 0;
			}
			else if (mModbusRtuDataRec->usRegAddr == 0x2038 && mModbusRtuDataRec->tFunction == ReadReg) //读efuse写入的SN
			{
				// password check
				ESP_LOGE("CHECK","0x2038 Reg,data = %x,%x,%x,%x,%x,%x,%x,%x",mModbusRtuDataRec->ucData[0],mModbusRtuDataRec->ucData[1],mModbusRtuDataRec->ucData[2],mModbusRtuDataRec->ucData[3],mModbusRtuDataRec->ucData[4],mModbusRtuDataRec->ucData[5],mModbusRtuDataRec->ucData[6],mModbusRtuDataRec->ucData[7]);
				// J_ZX_info_store(&mModbusRtuDataRec, &tModbusRtuDataSend);
				uint8_t sn_temp[24];
				ESP_ERROR_CHECK(esp_efuse_read_field_blob(SN_ZONE, sn_temp, 8*24));
				mModbusRtuDataSend->ucEffect = MODBUS_RESULT_SUCCESS;
				mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead;   //基本回复
				mModbusRtuDataSend->ucSlaveAddr = 0;
				mModbusRtuDataSend->tFunction = ReadReg;
				mModbusRtuDataSend->usRegAddr = mModbusRtuDataRec->usRegAddr;
				mModbusRtuDataSend->usDataLen = mModbusRtuDataRec->usRegCount * 2;
				mModbusRtuDataSend->usRegCount = mModbusRtuDataRec->usRegCount;
				mModbusRtuDataSend->ucData[0] = 0xED;
				mModbusRtuDataSend->ucData[1] = sn_res;

				if(mModbusRtuDataRec->usRegCount == 13)
				{
					memcpy((mModbusRtuDataSend->ucData) + 2,sn_temp,24);
				}
				mModbusRtuDataSend->ucError = 0;
				i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
				esp_log_buffer_hex(TAG, mDataSend, i);
				ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
			}
			else
			{
				// ESP_LOGW("tag","J_login_manage[%d].connect_Login = %x,Zhong_xin_Switch = %x",(int)mModbusRtuDataRec->tTag,J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login,Zhong_xin_Switch);
				// if(Zhong_xin_Switch ==  9 || J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login == 0x6F || Zhong_Xin_Login == 0x6F) // 9：关闭密码模式 6：开启密码模式
				// {
					xSemaphoreTake(ModbusTCP_handle_sem, portMAX_DELAY);
					CFG_dProcess_Protocol(mModbusRtuDataRec, mModbusRtuDataSend);
					xSemaphoreGive(ModbusTCP_handle_sem); 
					if(mModbusRtuDataSend->ucEffect == MODBUS_RESULT_SUCCESS)
					{
						mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead;
						i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
						ESP_LOGW(TAG, "before send() mModbusRtuDataRec->tTag:%d", (int)mModbusRtuDataRec->tTag);
						esp_log_buffer_hex(TAG, mDataSend, i);
						ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
						if((mModbusRtuDataSend->tFunction == WriteReg || mModbusRtuDataSend->tFunction == WriteMultReg)
							&& mModbusRtuDataSend->usRegAddr == 0x00BB)
						{
							vEsp32Restart();
						}
					}
				// }
				// else
				// {
				// 	mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead; //基本回复
				// 	mModbusRtuDataSend->ucSlaveAddr = mModbusRtuDataRec->ucSlaveAddr;			
				// 	mModbusRtuDataSend->tFunction = mModbusRtuDataRec->tFunction + 0x80;
				// 	mModbusRtuDataSend->usDataLen = 0;
				// 	mModbusRtuDataSend->ucError = 12;//MODBUS_ERROR_CODE_GW_TGT_FAILED;
				// 	mModbusRtuDataSend->ucEffect = MODBUS_RESULT_SUCCESS;

				// 	i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
				// 	esp_log_buffer_hex(TAG, mDataSend, i);
				// 	ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
				// }
				
			}
		}
		else
		{
			// if(Zhong_xin_Switch ==  9 || J_login_manage[(int)mModbusRtuDataRec->tTag].connect_Login == 0x6F || Zhong_Xin_Login == 0x6F) // 9：关闭密码模式 6：开启密码模式
			// {
				tMyQueueData.tMyQueueCommand.tMyQueueCommandType = mModbusRtuDataRec->tFunction;
				tMyQueueData.tMyQueueCommand.usSlaveAddr = mModbusRtuDataRec->ucSlaveAddr;
				tMyQueueData.tMyQueueCommand.usRegAddr = mModbusRtuDataRec->usRegAddr;
				tMyQueueData.tMyQueueCommand.usRegLen = mModbusRtuDataRec->usRegCount;
				tMyQueueData.tMyQueueCommand.usDatalen = mModbusRtuDataRec->usDataLen;
				tMyQueueData.tMyQueueCommand.ucError = mModbusRtuDataRec->ucError;
				memcpy(tMyQueueData.tMyQueueCommand.cData, mModbusRtuDataRec->ucData, tMyQueueData.tMyQueueCommand.usDatalen);
				tMyQueueData.Reserver[0] = (uint32_t)mModbusRtuDataRec->tTag;
				tMyQueueData.Reserver[1] = mModbusRtuDataRec->usHead;
				xQueueSend(mEthQueueRec, (void * )&tMyQueueData, (TickType_t)0);
				ESP_LOGW(TAG, "check send data to queue flow");
			// }
			// else
			// {
			// 	mModbusRtuDataSend->usHead = mModbusRtuDataRec->usHead; //基本回复
			// 	mModbusRtuDataSend->ucSlaveAddr = mModbusRtuDataRec->ucSlaveAddr;			
			// 	mModbusRtuDataSend->tFunction = mModbusRtuDataRec->tFunction + 0x80;
			// 	mModbusRtuDataSend->usDataLen = 0;
			// 	mModbusRtuDataSend->ucError = 12;//MODBUS_ERROR_CODE_GW_TGT_FAILED;
			// 	mModbusRtuDataSend->ucEffect = MODBUS_RESULT_SUCCESS;

			// 	i = MODB_dBuild_TCP(mModbusRtuDataSend, (uint8_t *)mDataSend);
			// 	esp_log_buffer_hex(TAG, mDataSend, i);
			// 	ETH_vData_Send((int)mModbusRtuDataRec->tTag, mDataSend, i);
			// }
		}
		mModbusRtuDataRec->ucEffect = MODBUS_RESULT_FAIL;
	}
	memset(mModbusRtuDataSend,0,sizeof(ModbusRtuDataTPDF));
	memset(mModbusRtuDataRec,0,sizeof(ModbusRtuDataTPDF));
	
}

static uint8_t NetworkConnetStatus()
{
	uint8_t mNetworkConnected;
	uint8_t mEthConnected;
	uint8_t mWifiConnected;

	mEthConnected = Eth_Connected_Status();
	mWifiConnected = Wifi_Connected_Status();
	if (mEthConnected == 1 || mWifiConnected == 1)
	{
		mNetworkConnected = 1;
	}
	else
	{
		mNetworkConnected = 0;
	}
	//store gateway net status
	if(mPartitionTable.BasicInfor.RunState != mNetworkConnected)
	{
		mPartitionTable.BasicInfor.RunState = mNetworkConnected;
		CFG_vSaveConfig(0x020C - 1);
	}
	return mNetworkConnected;
}

/*tcp socket entrance*/
void vSocket_vTsk_Start(void *pvParameters)
{
	MyQueueDataTPDF tMyQueueData;
	uint8_t mNetworkConnected;
	uint8_t mEthConnected;
	uint8_t mWifiConnected;
	vTcpSockets_vInit();
	while(1)
	{
        mNetworkConnected = NetworkConnetStatus();
		mEthConnected = Eth_Connected_Status();
		mWifiConnected = Wifi_Connected_Status();
		Eth_Socket_vTsk(mEthConnected | mWifiConnected, tMyQueueData);
		vTaskDelay(1);
		switch(mServerProtocolType)
		{
			case SERVER_PROTOCOL_TYPE_MQTT:
				vTaskDelay(200);
				break;
			case SERVER_PROTOCOL_TYPE_MODBUS_RTU:
				break;
			default:
				break;
		}
		//vTaskDelay(20);
	}
}

/*pass a structure pointer of ModbusRtuDataTPDF */
ModbusRtuDataTPDF *pModbusRtuDataRec(void)
{
	return mModbusRtuDataRec;
}